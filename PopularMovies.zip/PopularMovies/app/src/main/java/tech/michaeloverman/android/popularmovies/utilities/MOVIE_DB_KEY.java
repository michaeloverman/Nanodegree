package tech.michaeloverman.android.popularmovies.utilities;

/**
 * An untracked class to hold my API_KEY. Get your own...
 * Created by Michael on 12/8/2016.
 */

final class MOVIE_DB_KEY {
    public static String KEY = "5b976994bbbba17e3b2e4d2431b5fc2b";
}
